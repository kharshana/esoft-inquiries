app.directive('getDirective', function ($window) {
    return {
        restrict: 'AE',
        //templateUrl: 'views/search-box.html',
        link: function (scope, element, attributes) {
        	
            // Content Area Height & Width

            function contentHeight() {
                var windowHeight = $(window).height();
                var windowWidth = $(window).width();
                var headerHeight = angular.element('header').height();
                var sidebarWidth = angular.element('.sidebar').width();
                var contentHeight = windowHeight - headerHeight + 'px';
                var contentWidth = windowWidth - sidebarWidth + 'px';
                angular.element('.content').css({"height":contentHeight,"margin-top":headerHeight,"width":contentWidth});
            }
            
            contentHeight();

            $(window).resize(function(){
                contentHeight();
            });

            // Google Material Design effect for buttons

            $('button, .mbutton').mawbutton({
                speed : 250,
                scale : 6,
                effect : "ripple",
                transitionEnd:function(){
                    //console.log('end');
                }
            });
        }
    };
});
