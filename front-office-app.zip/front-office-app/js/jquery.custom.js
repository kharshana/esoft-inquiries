$(document).ready(function () {

	/*// Content Area Height & Width

            function contentHeight() {
                var windowHeight = $(window).height();
                var windowWidth = $(window).width();
                var headerHeight = angular.element('header').height();
                var sidebarWidth = angular.element('.sidebar').width();
                var contentHeight = windowHeight - headerHeight + 'px';
                var contentWidth = windowWidth - sidebarWidth + 'px';
                angular.element('.content').css({"height":contentHeight,"margin-top":headerHeight,"width":contentWidth});
            }
            
            contentHeight();

            $(window).resize(function(){
                contentHeight();
            });

            // Google Material Design effect for buttons

            $('button, .mbutton').mawbutton({
                speed : 250,
                scale : 6,
                effect : "ripple",
                transitionEnd:function(){
                    //console.log('end');
                }
            });
*/
    // Top Navbar Dropdowns

    $('.notifications > li, .user-profile > li').on('click',function(){
	    $(this).addClass("active");
	    $(".notifications > li, .user-profile > li").not(this).find('.dropdownCont').fadeOut('fast');
	    $(this).find('.dropdownCont').fadeToggle('fast');
    	return false;
    });

	$("html").not(".notifications > li, .user-profile > li").on('click',function(){
		$('.dropdownCont').fadeOut('fast');
	});
    
    $('.dropdownCont, .dropdownCont a').on('click',function(){
	    return false;
    });

    // Tooltips

    $(function () {
	  $('[data-toggle="tooltip"]').tooltip();
	});

	// Custom File input

	$('input[type=file]').customFile();

});