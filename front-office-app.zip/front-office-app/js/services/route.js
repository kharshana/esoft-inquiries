app.config(function ($routeProvider, $locationProvider) {

    $locationProvider.html5Mode(true);

    $routeProvider.when('/', {
        templateUrl: 'views/index.html',
        controller: 'indexController'
    });

    $routeProvider.when('/full-registration', {
        templateUrl: 'views/student-full-information.html',
        controller: 'registerController'
    });

    $routeProvider.otherwise({
        redirectTo: '/'
    });
    // use the HTML5 History API


});