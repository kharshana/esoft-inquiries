app.controller('indexController', ['$scope', function($scope) {

}]);